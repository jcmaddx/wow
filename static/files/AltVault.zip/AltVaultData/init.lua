local _, core = ...; -- Namespace

local SLOT_NAMES = {
	"HEADSLOT",
	"NECKSLOT",
	"SHOULDERSLOT",
	"BACKSLOT",
	"CHESTSLOT",
	"SHIRTSLOT",
	"TABARDSLOT",
	"WRISTSLOT",
	"HANDSSLOT",
	"WAISTSLOT",
	"LEGSSLOT",
	"FEETSLOT",
	"FINGER0SLOT",
	"FINGER1SLOT",
	"TRINKET0SLOT",
	"TRINKET1SLOT",
	"MAINHANDSLOT",
	"SECONDARYHANDSLOT"
}

function core:Print(...)
    local hex = "00ccff";
    local prefix = string.format("|cff%s%s|r", hex:upper(), "AltVault:");	
    DEFAULT_CHAT_FRAME:AddMessage(string.join(" ", prefix, ...));
end

function charInDB(charGUID)
	for index, character in pairs(AltVaultDB.characters) do
		if character.GUID == charGUID then
			return index
		end
	end
	return false;
end

function core:initDB()
	local charGUID = UnitGUID("player");
	local dbIndex = charInDB(charGUID);
	local charIndex
	if not dbIndex then
		-- Alert that the character is being added
		showInitialAlert()
		charIndex = #AltVaultDB.characters + 1;
		AltVaultDB.characters[charIndex] = {};
	else
		charIndex = dbIndex
	end

	local hasMail = false --type(latestMail)
	local gear = {};
	local title = GetTitleName(GetCurrentTitle());

	local gender = UnitSex("player");
	gender = (gender == 2) and "male" or "female";

	local raceName = UnitRace("player");
	local specID, specName, _, specBackground, role = GetSpecializationInfo(GetSpecialization(), false, false, false);
	local restStateName = select(2, GetRestState())
	local restedXP = GetXPExhaustion();
	local itemLevel = select(2, GetAverageItemLevel())
	local ilvlR, ilvlG, ilvlB = GetItemLevelColor()
	AltVaultDB.characters[charIndex]["GUID"] = charGUID;
	AltVaultDB.characters[charIndex]["character"] = {
		["faction"] = UnitFactionGroup("player"),
		["name"] = UnitName("player"),
		["realm"] = GetRealmName(),
		["level"] = UnitLevel("player"),
		["race"] = raceName,
		["class"] = UnitClass("player"),
		["specID"] = specID,
		["specName"] = specName,
		["specBackground"] = specBackground,
		["role"] = role,
		["sex"] = gender,
		["title"] = title,
		["xp"] = UnitXP("player"),
		["xpMax"] = UnitXPMax("player"),
		["restState"] = restStateName,
		["restedXP"] = restedXP,
		["money"] = GetMoney(),
		["ilvl"] = floor(itemLevel),
		["ilvlColor"] ={
			["red"] = ilvlR, 
			["green"] = ilvlG,
			["blue"] = ilvlB
		}
	};
	if not dbIndex then
		AltVaultDB.characters[charIndex]["character"]["bankWarned"] = false
	end
	for i, slot in ipairs(SLOT_NAMES) do
		local slotID = GetInventorySlotInfo(slot);
		local equippedItem = GetInventoryItemID("player", slotID);
		if equippedItem then
			local itemLink = GetInventoryItemLink("player", slotID);
			local itemString = select(3, strfind(itemLink, "|H(.+)|h"));
			equippedItem = itemString;
		end
		gear[slot] = equippedItem;
	end
	AltVaultDB.characters[charIndex]["gear"] = gear;
	RequestTimePlayed()
	local currentHonor = UnitHonor("player");
	local maxHonor = UnitHonorMax("player");
	local honorLevel = UnitHonorLevel("player");
	local tierID = C_PvP.GetSeasonBestInfo();
	local tierInfo = C_PvP.GetPvpTierInfo(tierID);
	local tierIcon = tierInfo.tierIconID;
	local currentConquest, maxConquest = PVPGetConquestLevelInfo();

	AltVaultDB.characters[charIndex]["pvp"] = {
		["honor"] = currentHonor,
		["kills"] = GetPVPLifetimeStats(),
		["maxHonor"] = maxHonor,
		["honorLevel"] = honorLevel,
		["tierID"] = tierID,
		["tierIcon"] = tierIcon,
		["currentConquest"] = currentConquest,
		["maxConquest"] = maxConquest
	}

	if AltVaultDB.characters[charIndex]["bags"] == nil then
		AltVaultDB.characters[charIndex]["bags"] = {}
	end
	if AltVaultDB.characters[charIndex]["bank"] == nil then
		AltVaultDB.characters[charIndex]["bank"] = {
			["bag-13"] = {}, -- placeholder for bank
			["bag-14"] = {} -- placeholder for reagents
		}
	end
	for bagID = 0, NUM_BAG_SLOTS do
		if AltVaultDB.characters[charIndex].bags['bag-'..bagID+1] == nil then
			AltVaultDB.characters[charIndex].bags['bag-'..bagID+1] = {}
		end
		GetBagInfo(bagID, charIndex)
	end

	if AltVaultDB.characters[charIndex]["professions"] == nil then
		AltVaultDB.characters[charIndex]["professions"] = {}
	end
	
	local prof1, prof2, arch, fish, cook = GetProfessions();
	local professionData = {
		["prof1"] = prof1,
		["prof2"] = prof2,
		["arch"] = arch,
		["fish"] = fish,
		["cook"] = cook
	}
	for key, prof in pairs(professionData) do
		if prof ~= nil then
			local name, texture, rank, maxRank, numSpells, spelloffset, _, rankModifier, _, _, skillLineName = GetProfessionInfo(prof);
			local prof_title = "";
			if (skillLineName) then
				prof_title = skillLineName;
			else
				for i=1,#PROFESSION_RANKS do
					local value,title = PROFESSION_RANKS[i][1], PROFESSION_RANKS[i][2];
					if maxRank < value then break end
					prof_title = title;
				end
			end
			local specializationName
			if (name == "Alchemy" or name =="Engineering") then
				local spellName, _, spellID = GetSpellBookItemName(numSpells + spelloffset, "professions");
				specializationName = spellName
			end
			AltVaultDB.characters[charIndex].professions[key] = {
				["name"] = name,
				["skillName"] = prof_title,
				["icon"] = texture,
				["skill"] = rank,
				["maxSkill"] = maxRank,
				["skillModifier"] = rankModifier,
				["specializationName"] = specializationName,
			}
		end
	end
end

function showInitialAlert()
	MainMenuMicroButton_ShowAlert(CollectionsMicroButtonAlert, "This character has been added to your collection!")
	MicroButtonPulse(CollectionsMicroButton);
end

function GetBagInfo(bagID, charIndex)
	if charIndex == nil then return end
	local bagKey = 'bag-'..bagID+1
	local typeKey = "bags"
	local numSlots = GetContainerNumSlots(bagID)
	local numFreeSlots = GetContainerNumFreeSlots(bagID)
	if bagID == -1 then -- primary bank slot
		bagKey = "bag-13"
		typeKey = "bank"
		AltVaultDB.characters[charIndex][typeKey][bagKey]["icon"] = "Interface\\Buttons\\Button-Backpack-Up"
	elseif bagID == -3 then -- reagent bank slot
		bagKey = "bag-14"
		typeKey = "bank"
		AltVaultDB.characters[charIndex][typeKey][bagKey]["icon"] = "Interface\\ICONS\\ACHIEVEMENT_GUILDPERK_BOUNTIFULBAGS"
	elseif bagID == 0 then	-- Bag 0	
		AltVaultDB.characters[charIndex][typeKey][bagKey]["icon"] = "Interface\\Buttons\\Button-Backpack-Up"
	else						-- Bags 1 through 11
		if bagID > NUM_BAG_SLOTS then
			typeKey = "bank"
		end
		AltVaultDB.characters[charIndex][typeKey][bagKey]["icon"] = GetInventoryItemTexture("player", ContainerIDToInventoryID(bagID))
		bagLink = GetInventoryItemLink("player", ContainerIDToInventoryID(bagID))
		AltVaultDB.characters[charIndex][typeKey][bagKey]["link"] = bagLink
		if bagLink then
			local _, _, rarity = GetItemInfo(bagLink)
			if rarity then	-- in case rarity was known from a previous scan, and GetItemInfo returns nil for some reason .. don't overwrite
				AltVaultDB.characters[charIndex][typeKey][bagKey]["rarity"] = rarity
			end
		end
	end

	AltVaultDB.characters[charIndex][typeKey][bagKey]["slots"] = numSlots
	AltVaultDB.characters[charIndex][typeKey][bagKey]["freeSlots"] = numFreeSlots
	if AltVaultDB.characters[charIndex][typeKey][bagKey]["items"] == nil then
		AltVaultDB.characters[charIndex][typeKey][bagKey]["items"] = {}
	end
	if AltVaultDB.characters[charIndex][typeKey][bagKey]["counts"] == nil then
		AltVaultDB.characters[charIndex][typeKey][bagKey]["counts"] = {}
	end
	for itemID = 1, numSlots do
		local itemIcon, itemCount, _, itemQuality, _, _, itemLink = GetContainerItemInfo(bagID, itemID);
		AltVaultDB.characters[charIndex][typeKey][bagKey]["items"][itemID] = {
			["link"] = itemLink,
			["icon"] = itemIcon,
			["rarity"] = itemQuality
		}
		if itemCount and itemCount > 1 then
			AltVaultDB.characters[charIndex][typeKey][bagKey]["counts"][itemID] = itemCount
		end
	end

end

function updatePlayerData(player, category, key, value)
	if key ~= nil then
		AltVaultDB.characters[player][category][key] = value
	else
		AltVaultDB.characters[player][category] = value
	end
end

function updateData(key, value)
	AltVaultDB.data[key] = value
end

function core:init(event,  ...)
	local charID
	if event == 'PLAYER_LOGIN' then
		if not AltVaultDB then
			AltVaultDB = {}
			AltVaultDB["data"] = {
				["tokenPrice"] = nil,
				["tokenPriceUpdated"] = nil,
				["shownIntro"] = false
			}
			AltVaultDB["characters"] = {}
		end
		core.initDB();
	elseif event == "ACTIVE_TALENT_GROUP_CHANGED" then
		if AltVaultDB == nil then return end
		charID = charInDB(UnitGUID("player"));
		if charID == false then return end
		local specID, specName, _, specBackground, role = GetSpecializationInfo(GetSpecialization(), false, false, false);
		updatePlayerData(charID, 'character', 'specID', specID)
		updatePlayerData(charID, 'character', 'specName', specName)
		updatePlayerData(charID, 'character', 'specBackground', specBackground)
		updatePlayerData(charID, 'character', 'role', role)
	elseif event == 'BANKFRAME_OPENED' or event == 'BANKFRAME_CLOSED' then
		charID = charInDB(UnitGUID("player"));
		for bankSlotID = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
			if AltVaultDB.characters[charID]["bank"]['bag-'..bankSlotID+1] == nil then
				AltVaultDB.characters[charID]["bank"]['bag-'..bankSlotID+1] = {}
			end
			GetBagInfo(bankSlotID, charID)
		end
		GetBagInfo(BANK_CONTAINER, charID)
		if IsReagentBankUnlocked() then
			GetBagInfo(REAGENTBANK_CONTAINER, charID)
		end
		AltVaultDB.characters[charID]["character"]["bankWarned"] = true
	elseif event == 'BAG_UPDATE' then
		-- need to do this
	elseif event == 'UPDATE_PENDING_MAIL' then
		local hasMail = HasNewMail()
		charID = charInDB(UnitGUID("player"));
		updatePlayerData(charID, 'character', 'hasMail', hasMail)
	elseif event == "PLAYER_MONEY" then
		charID = charInDB(UnitGUID("player"));
		updatePlayerData(charID, 'character', 'money', GetMoney())
	elseif event == "AUCTION_HOUSE_SHOW" or event == "AUCTION_HOUSE_CLOSED" then
		local marketPrice = C_WowTokenPublic.GetCurrentMarketPrice()
		local currentTime = C_DateAndTime.GetCurrentCalendarTime()
		updateData('tokenPrice', marketPrice)
		updateData('tokenPriceUpdated', currentTime)
	elseif event == "PLAYER_GUILD_UPDATE" then
		local bkgR, bkgG, bkgB, borderR, borderG, borderB, emblemR, emblemG, emblemB, emblemFilename = GetGuildLogoInfo();
		if AltVaultDB == nil or bkgR == nil then return end
		charID = charInDB(UnitGUID("player"));
		local guildInfo = {}
		if IsInGuild() then
			local guildName, guildRank = GetGuildInfo("player")
			local numGuildies = GetNumGuildMembers()
			guildInfo = {
				["name"] = guildName,
				["rank"] = guildRank,
				["members"] = numGuildies,
				["tabard"] = {
					["bgR"] = bkgR / 255,
					["bgG"] = bkgG / 255,
					["bgB"] = bkgB / 255,
					["borderR"] = borderR / 255,
					["borderG"] = borderG / 255,
					["borderB"] = borderB / 255,
					["emblemR"] = emblemR / 255,
					["emblemG"] = emblemG / 255,
					["emblemB"] = emblemB / 255,
					["emblemTexture"] = emblemFilename
				}
			}
		else
			guildInfo = {}
		end
		updatePlayerData(charID, 'guild', nil, guildInfo)
	elseif event == "TIME_PLAYED_MSG" then
		local total = ...
		charID = charInDB(UnitGUID("player"));
		updatePlayerData(charID, 'character', 'played', total)
	end
end

AltVaultEvents = CreateFrame("Frame");
AltVaultEvents:RegisterEvent("ADDON_LOADED");
AltVaultEvents:RegisterEvent("PLAYER_LOGIN");
AltVaultEvents:RegisterEvent("UPDATE_PENDING_MAIL");
AltVaultEvents:RegisterEvent("PLAYER_MONEY");
AltVaultEvents:RegisterEvent("AUCTION_HOUSE_SHOW");
AltVaultEvents:RegisterEvent("AUCTION_HOUSE_SHOW");
AltVaultEvents:RegisterEvent("AUCTION_HOUSE_CLOSED");
AltVaultEvents:RegisterEvent("PLAYER_GUILD_UPDATE");
AltVaultEvents:RegisterEvent("PLAYER_ALIVE");
AltVaultEvents:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED");
AltVaultEvents:RegisterEvent("HONOR_XP_UPDATE");
AltVaultEvents:RegisterEvent("TIME_PLAYED_MSG");
AltVaultEvents:RegisterEvent("BANKFRAME_OPENED");
AltVaultEvents:RegisterEvent("BANKFRAME_CLOSED");
-- AltVaultEvents:RegisterEvent("BAG_UPDATE");  -- need to do this
-- events:RegisterEvent("PLAYER_EQUIPMENT_CHANGED");

AltVaultEvents:SetScript("OnEvent", core.init);

