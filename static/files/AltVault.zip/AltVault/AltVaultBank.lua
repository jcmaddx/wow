--------------------------------------
-- Namespaces
--------------------------------------
local _, core = ...
core.AltVaultBank = {}

local AltVault = core.AltVault
local AltVaultBank = core.AltVaultBank

local ITEMS_PER_ROW = 8
local ICON_HEIGHT = 44
local CONTAINER_PADDING = 68
local MOST_SLOTS_POSSIBLE = 36
local BANK_SLOTS = 28
local REAGENT_BANK_SLOTS = 98

function AltVaultBankFrame_OnLoad(self)
    local scrollFrame = AltBankScrollFrame
    local scrollChild = AltBankScrollFrameScrollChild
    local containerHeight = CONTAINER_PADDING + (ceil(MOST_SLOTS_POSSIBLE / ITEMS_PER_ROW) * ICON_HEIGHT)
    scrollFrame:SetScrollChild(scrollChild)
    scrollChild:SetWidth(scrollFrame:GetWidth())
    -- create the primary bank frame
    local primaryContainer = CreateFrame("Frame", "$parentAltBankContainer13", scrollChild, "AltBagContainerTemplate")
    primaryContainer:SetID(13)
    for bankSlotID = 1, BANK_SLOTS do
        local itemFrame = CreateFrame("ItemButton", "$parentAltBagItem"..bankSlotID, primaryContainer, "AltVaultBagItemTemplate")
        itemFrame:SetID(bankSlotID)
        itemFrame:SetScript("OnEnter", AltBankSlotButton_OnEnter)
        itemFrame:SetScript("OnClick", AltBankSlotButton_OnModifiedClick)
        local rowID = ceil(bankSlotID / ITEMS_PER_ROW)
        if rowID > 1 and (bankSlotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
            local offsetID = bankSlotID - ITEMS_PER_ROW
            itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
        elseif bankSlotID ~= 1 then
            itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..bankSlotID-1, "TOPRIGHT", 4, 0)
        end
    end
    -- create the reagent bank frame
    local reagentContainer = CreateFrame("Frame", "$parentAltBankContainer14", scrollChild, "AltBagContainerTemplate")
    reagentContainer:SetPoint("TOPLEFT", "$parentAltBankContainer13", "BOTTOMLEFT")
    reagentContainer:SetID(14)
    for reagentSlotID = 1, REAGENT_BANK_SLOTS do
        local itemFrame = CreateFrame("ItemButton", "$parentAltBagItem"..reagentSlotID, reagentContainer, "AltVaultBagItemTemplate")
        itemFrame:SetID(reagentSlotID)
        itemFrame:SetScript("OnEnter", AltBankSlotButton_OnEnter)
        itemFrame:SetScript("OnClick", AltBankSlotButton_OnModifiedClick)
        local rowID = ceil(reagentSlotID / ITEMS_PER_ROW)
        if rowID > 1 and (reagentSlotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
            local offsetID = reagentSlotID - ITEMS_PER_ROW
            itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
        elseif reagentSlotID ~= 1 then
            itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..reagentSlotID-1, "TOPRIGHT", 4, 0)
        end
    end
    -- create all the bank bag frames
    for bagID = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
        local bagContainer = CreateFrame("Frame", "$parentAltBankContainer"..bagID+1, scrollChild, "AltBagContainerTemplate")
        bagContainer:SetHeight(containerHeight)
        bagContainer:SetID(bagID + 1)
        if bagID == NUM_BAG_SLOTS + 1 then
            bagContainer:SetPoint("TOPLEFT", "$parentAltBankContainer14", "BOTTOMLEFT")
        else
            bagContainer:SetPoint("TOPLEFT", "$parentAltBankContainer"..bagID, "BOTTOMLEFT")
        end
        for slotID = 1, MOST_SLOTS_POSSIBLE do
            local itemFrame = CreateFrame("ItemButton", "$parentAltBagItem"..slotID, bagContainer, "AltVaultBagItemTemplate")
            itemFrame:SetID(slotID)
            itemFrame:SetScript("OnEnter", AltBankSlotButton_OnEnter)
            itemFrame:SetScript("OnClick", AltBankSlotButton_OnModifiedClick)
            local rowID = ceil(slotID / ITEMS_PER_ROW)
            if rowID > 1 and (slotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
                local offsetID = slotID - ITEMS_PER_ROW
                itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
            elseif slotID ~= 1 then
                itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..slotID-1, "TOPRIGHT", 4, 0)
            end
        end
        bagContainer:Show()
    end
end

function AltVaultBankFrame_OnShow(self)
	UpdateBankBags()
end

function UpdateBankBags()
    local bankBags = AltVaultDB.characters[CharacterJournal.activeAlt].bank
    local scrollChild = AltBankScrollFrameScrollChild
    local bankFrames = { scrollChild:GetChildren() }
    if bankBags["bag-13"].slots ~= nil then -- the default bank has slots
        AltBankNotAvailable:Hide()
        scrollChild:SetHeight(GetTotalBankHeight() + 20)
        for bagID, bagContainer in ipairs(bankFrames) do
            local bankBagID = GetBankBagID(bagID)
            local bagData = bankBags["bag-"..bankBagID]
            local numSlots = bagData.slots
            local containerHeight
            if numSlots ~= nil and numSlots ~= 0 then
                containerHeight = CONTAINER_PADDING + (ceil(numSlots / ITEMS_PER_ROW) * ICON_HEIGHT)
            else
                containerHeight = 100; -- calculate locked containers
            end
            bagContainer:SetHeight(containerHeight)
            bagContainer.BagTitle.AltBagIcon:SetVertexColor(1.0,1.0,1.0)
            bagContainer.BagLocked:Hide()
            if bagData.link then
                local item = Item:CreateFromItemLink(bagData.link)
                item:ContinueOnItemLoad(function()
                    local itemName, _, itemRarity = GetItemInfo(bagData.link)
                    bagContainer.BagTitle.AltBagTitle:SetText(itemName)
                    bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(itemRarity))
                    if #itemName >= 30 then
                        bagContainer.BagTitle.AltBagTitle:SetFontObject(GameFontHighlight)
                    end
                end)
                bagContainer.BagTitle.AltBagIcon:SetTexture(bagData.icon)
                bagContainer.BagTitle.AltBagCapacity:SetText(bagData.slots - bagData.freeSlots..'/'..bagData.slots)
                
            elseif bagData.slots == 28 then -- the default bank
                bagContainer.BagTitle.AltBagTitle:SetText("Bank")
                bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(1))
                bagContainer.BagTitle.AltBagCapacity:SetText(bagData.slots - bagData.freeSlots..'/'..bagData.slots)
            elseif bagData.slots == 0 then -- locked bags
                bagContainer.BagTitle.AltBagTitle:SetText("Bag "..bagID -2)
                bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(1))
                bagContainer.BagTitle.AltBagIcon:SetTexture("Interface\\Buttons\\Button-Backpack-Up")
                bagContainer.BagTitle.AltBagIcon:SetVertexColor(1.0,0.1,0.1)
                bagContainer.BagTitle.AltBagCapacity:SetText("0/0")
                bagContainer.BagLocked:Show()
            else -- it must be the reagent bank then
                bagContainer.BagTitle.AltBagTitle:SetText("Reagent Bank")
                bagContainer.BagTitle.AltBagIcon:SetTexture("Interface\\ICONS\\ACHIEVEMENT_GUILDPERK_BOUNTIFULBAGS")
                bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(1))
                if bagData.slots == nil then
                    bagContainer.BagTitle.AltBagIcon:SetVertexColor(1.0,0.1,0.1)
                    bagContainer.BagTitle.AltBagCapacity:SetText("0/0")
                    bagContainer.BagLocked:Show()
                else
                    bagContainer.BagTitle.AltBagCapacity:SetText(bagData.slots - bagData.freeSlots..'/'..bagData.slots)
                end
            end
            
            local bagItems = { bagContainer:GetChildren() }
            table.remove(bagItems, 1)
            table.remove(bagItems, 1)
            for slotID, itemFrame in ipairs(bagItems) do
                if numSlots and slotID <= numSlots then
                    local rowID = ceil(slotID / ITEMS_PER_ROW)
                    if rowID > 1 and (slotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
                        local offsetID = slotID - ITEMS_PER_ROW
                        itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
                    elseif slotID ~= 1 then
                        itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..slotID-1, "TOPRIGHT", 4, 0)
                    end
                    local texture = _G[itemFrame:GetName().."IconTexture"]
                    local slotItem = bagData.items[tonumber(slotID)]
                    local itemCount = bagData.counts[tonumber(slotID)]
                    if slotItem.link ~= nil then
                        texture:SetTexture(slotItem.icon)
                        SetItemButtonQuality(itemFrame, slotItem.rarity, 1)
                        if itemCount ~= nil then
                            SetItemButtonCount(itemFrame, itemCount)
                        else
                            SetItemButtonCount(itemFrame, nil)
                        end
                    else
                        texture:SetTexture("Interface\\PaperDoll\\UI-Backpack-EmptySlot")
                        SetItemButtonQuality(itemFrame, 1, 1)
                        SetItemButtonCount(itemFrame, nil)
                    end
                    itemFrame:Show()
                else
                    itemFrame:Hide()
                end
                bagContainer:Show()
            end
        end
    else
        AltBankNotAvailable:Show()
        scrollChild:SetHeight(0)
        for bagID, bagContainer in ipairs(bankFrames) do
            bagContainer:Hide()
        end
    end
end

function GetBankBagID(id)
    if id == 1 then
        return 13
    elseif id == 2 then
        return 14
    else
        return id + NUM_BAG_SLOTS - 1
    end
end

function GetTotalBankHeight()
    local bank = AltVaultDB.characters[CharacterJournal.activeAlt].bank
    local totalHeight = 0
    for key, container in pairs(bank) do
        local numRows = 0
        if container.slots ~= nil and container.slots ~= 0 then
            numRows = ceil(container.slots / ITEMS_PER_ROW)
            totalHeight = totalHeight + (CONTAINER_PADDING + (numRows * ICON_HEIGHT))
        else
            totalHeight = totalHeight + 100
        end
    end
    return totalHeight
end

function AltBankScroll_OnScroll(self, delta)
    local newValue = self:GetVerticalScroll() - (delta * 50)

    if newValue < 0 then
        newValue = 0
    elseif newValue > self:GetVerticalScrollRange() then
        newValue = self:GetVerticalScrollRange()
    end
    self:SetVerticalScroll(newValue)
end

function AltBankSlotButton_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local parentID = self:GetParent():GetID()
    local itemData = AltVaultDB.characters[CharacterJournal.activeAlt].bank["bag-"..parentID].items[tonumber(self:GetID())]
    if itemData and itemData.link then
        local isBattlePet = itemData.link:match("|Hbattlepet:")
        if isBattlePet == nil then
            GameTooltip:SetHyperlink(itemData.link)
        else
            local _, speciesID, level, breedQuality, maxHealth, power, speed, battlePetID = strsplit(":", itemData.link)
            local name = select(8, C_PetJournal.GetPetInfoByPetID(battlePetID))
            BattlePetToolTip_Show(
                tonumber(speciesID),
                tonumber(level),
                tonumber(breedQuality),
                tonumber(maxHealth),
                tonumber(power),
                tonumber(speed),
                name
            );
        end
        CursorUpdate(self);
	end
end

function AltBankSlotButton_OnModifiedClick(self, button)
    if ( IsModifiedClick() ) then
        local parentID = self:GetParent():GetID()
        local itemData = AltVaultDB.characters[CharacterJournal.activeAlt].bank["bag-"..parentID].items[tonumber(self:GetID())]
        local _, itemHyperLink = GetItemInfo(itemData.link)
        if ( itemData and itemHyperLink ) then
            HandleModifiedItemClick(itemHyperLink)	
        end
    end
end