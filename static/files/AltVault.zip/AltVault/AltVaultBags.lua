--------------------------------------
-- Namespaces
--------------------------------------
local _, core = ...
core.AltVaultBags = {}

local AltVault = core.AltVault
local AltVaultBags = core.AltVaultBags

local ITEMS_PER_ROW = 8
local ICON_HEIGHT = 44
local CONTAINER_PADDING = 68
local MOST_SLOTS_POSSIBLE = 36

function AltVaultBagsFrame_OnLoad(self)
    local scrollFrame = AltBagsScrollFrame
    local scrollChild = AltBagsScrollFrameScrollChild
    local containerHeight = CONTAINER_PADDING + (ceil(MOST_SLOTS_POSSIBLE / ITEMS_PER_ROW) * ICON_HEIGHT)
    scrollFrame:SetScrollChild(scrollChild)
    scrollChild:SetWidth(scrollFrame:GetWidth())
    -- create all the frames
    for bagID = 1, NUM_BAG_SLOTS + 1 do
        local bagContainer = CreateFrame("Frame", "$parentAltBagContainer"..bagID, scrollChild, "AltBagContainerTemplate")
        bagContainer:SetHeight(containerHeight)
        if bagID ~= 1 then
            bagContainer:SetPoint("TOPLEFT", "$parentAltBagContainer"..bagID - 1, "BOTTOMLEFT")
        end
        for slotID = 1, MOST_SLOTS_POSSIBLE do
            local itemFrame = CreateFrame("ItemButton", "$parentAltBagItem"..slotID, bagContainer, "AltVaultBagItemTemplate")
            itemFrame:SetID(slotID)
            itemFrame:SetScript("OnEnter", AltBagSlotButton_OnEnter)
            itemFrame:SetScript("OnClick", AltBagSlotButton_OnModifiedClick)
            local rowID = ceil(slotID / ITEMS_PER_ROW)
            if rowID > 1 and (slotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
                local offsetID = slotID - ITEMS_PER_ROW
                itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
            elseif slotID ~= 1 then
                itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..slotID-1, "TOPRIGHT", 4, 0)
            end
        end
        bagContainer:Show()
    end
end

function AltVaultBagsFrame_OnShow(self)
	UpdateBags()
end

function UpdateBags()
    local scrollChild = AltBagsScrollFrameScrollChild
    scrollChild:SetHeight(GetTotalBagsHeight() + 20)
    local allBags = AltVaultDB.characters[CharacterJournal.activeAlt].bags
    local bagFrames = { scrollChild:GetChildren() }
    for bagID, bagContainer in ipairs(bagFrames) do
        local bagData = allBags["bag-"..bagID]
        local numSlots = bagData.slots
        local containerHeight = CONTAINER_PADDING + (ceil(numSlots / ITEMS_PER_ROW) * ICON_HEIGHT)
        bagContainer:SetHeight(containerHeight)

        if bagData.link then
            local item = Item:CreateFromItemLink(bagData.link)
            item:ContinueOnItemLoad(function()
                local itemName, _, itemRarity = GetItemInfo(bagData.link)
                bagContainer.BagTitle.AltBagTitle:SetText(itemName)
                if #itemName >= 30 then
                    bagContainer.BagTitle.AltBagTitle:SetFontObject(GameFontHighlight)
                end
                bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(itemRarity))
            end)
            bagContainer.BagTitle.AltBagIcon:SetTexture(bagData.icon)
            bagContainer.BagTitle.AltBagCapacity:SetText(bagData.slots - bagData.freeSlots..'/'..bagData.slots)
        else
            bagContainer.BagTitle.AltBagTitle:SetText("Backpack")
            bagContainer.BagTitle.AltBagTitle:SetTextColor(GetItemQualityColor(1))
        end
        
        local bagItems = { bagContainer:GetChildren() }
        table.remove(bagItems, 1)
        table.remove(bagItems, 1)
        for slotID, itemFrame in ipairs(bagItems) do
            if slotID <= numSlots then
                local rowID = ceil(slotID / ITEMS_PER_ROW)
                if rowID > 1 and (slotID - (ITEMS_PER_ROW * (rowID - 1)) == 1) then
                    local offsetID = slotID - ITEMS_PER_ROW
                    itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..offsetID, "BOTTOMLEFT", 0, -4)
                elseif slotID ~= 1 then
                    itemFrame:SetPoint("TOPLEFT", '$parentAltBagItem'..slotID-1, "TOPRIGHT", 4, 0)
                end
                local texture = _G[itemFrame:GetName().."IconTexture"]
                local slotItem = bagData.items[tonumber(slotID)]
                local itemCount = bagData.counts[tonumber(slotID)]
                if slotItem.link ~= nil then
                    texture:SetTexture(slotItem.icon)
                    SetItemButtonQuality(itemFrame, slotItem.rarity, 1)
                    if itemCount ~= nil then
                        SetItemButtonCount(itemFrame, itemCount)
                    else
                        SetItemButtonCount(itemFrame, nil)
                    end
                else
                    texture:SetTexture("Interface\\PaperDoll\\UI-Backpack-EmptySlot")
                    SetItemButtonQuality(itemFrame, 1, 1)
                    SetItemButtonCount(itemFrame, nil)
                end
                itemFrame:Show()
            else
                itemFrame:Hide()
            end
        end
    end
end

function GetTotalBagsHeight()
    local bags = AltVaultDB.characters[CharacterJournal.activeAlt].bags
    local totalHeight = 0
    for key, bag in pairs(bags) do
        local numRows = ceil(bag.slots / ITEMS_PER_ROW)
        totalHeight = totalHeight + (CONTAINER_PADDING + (numRows * ICON_HEIGHT))
    end
    return totalHeight
end

function AltBagScroll_OnScroll(self, delta)
    local newValue = self:GetVerticalScroll() - (delta * 50)

    if newValue < 0 then
        newValue = 0
    elseif newValue > self:GetVerticalScrollRange() then
        newValue = self:GetVerticalScrollRange()
    end
    self:SetVerticalScroll(newValue)
end

function AltBagSlotButton_OnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local parentID = strsub(self:GetParent():GetName(), -1)
    local itemData = AltVaultDB.characters[CharacterJournal.activeAlt].bags["bag-"..parentID].items[tonumber(self:GetID())]
    if itemData and itemData.link then
        local isBattlePet = itemData.link:match("|Hbattlepet:")
        if isBattlePet == nil then
            GameTooltip:SetHyperlink(itemData.link)
        else
            local _, speciesID, level, breedQuality, maxHealth, power, speed, battlePetID = strsplit(":", itemData.link)
            local name = select(8, C_PetJournal.GetPetInfoByPetID(battlePetID))
            BattlePetToolTip_Show(
                tonumber(speciesID),
                tonumber(level),
                tonumber(breedQuality),
                tonumber(maxHealth),
                tonumber(power),
                tonumber(speed),
                name
            );
        end
        CursorUpdate(self);
	end
end

function AltBagSlotButton_OnModifiedClick(self, button)
    if ( IsModifiedClick() ) then
        local parentID = strsub(self:GetParent():GetName(), -1)
        local itemData = AltVaultDB.characters[CharacterJournal.activeAlt].bags["bag-"..parentID].items[tonumber(self:GetID())]
        local _, itemHyperLink = GetItemInfo(itemData.link)
        if ( itemData and itemHyperLink ) then
            HandleModifiedItemClick(itemHyperLink)	
        end
    end
end