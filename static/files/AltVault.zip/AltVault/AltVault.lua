--------------------------------------
-- Namespaces
--------------------------------------
local _, core = ...
core.AltVault = {}

local AltVault = core.AltVault

local NUM_PAGES = 4
local LIST_FILTERS = {
	"All Realms / All Factions",
	"All Realms / Current Faction",
	"All Realms / Opposite Faction",
	"Current Realm / All Factions",
	"Current Realm / Current Faction",
	"Current Realm / Opposite Faction"
}

StaticPopupDialogs["NO_FILTER_RESULTS"] = {
	text = "No characters match that query.\nTry a different filter.",
	showAlert = true,
    button1 = "OK",
    OnAccept = function()
        StaticPopup_Hide("NO_FILTER_RESULTS")
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3
}

--------------------------------------
-- Defaults (usually a database!)
--------------------------------------
local defaults = {
	theme = {
		r = 0, 
		g = 0.8, -- 204/255
		b = 1,
		hex = "00ccff"
	}
}

--------------------------------------
-- Config functions
--------------------------------------

function AltVault:GetThemeColor()
	local c = defaults.theme
	return c.r, c.g, c.b, c.hex
end

--------------------------------------
-- Create Collections Tab
--------------------------------------

function AltVault:CreateCollectionsTab()
	local TabID = CollectionsJournal.numTabs + 1
	local Tab = CreateFrame("Button", "$parentTab"..TabID, CollectionsJournal, "CollectionsJournalTab", TabID)

	PanelTemplates_SetNumTabs(CollectionsJournal,TabID)
	Tab:SetPoint("LEFT", "$parentTab"..(TabID-1), "RIGHT", -16, 0)
	Tab:SetText("Characters")

	PanelTemplates_SetTab(CollectionsJournal, PanelTemplates_GetSelectedTab(CollectionsJournal))
	hooksecurefunc("CollectionsJournal_UpdateSelectedTab",function(self)
		local selected = CollectionsJournal_GetTab(self)
		CharacterJournal:SetShown(selected == TabID)
		if (selected == TabID) then
			CollectionsJournalTitleText:SetText("Characters")
		end
	end)
end

--------------------------------------
-- AltVault Event Handlers
--------------------------------------

function AltVault_OnShow(self)
	CollectionsJournalTitleText:SetText("Characters")
	CollectionsJournal:SetPortraitToAsset("Interface\\Icons\\ACHIEVEMENT_GUILDPERK_EVERYONES A HERO_RANK2")
	AltVault:SetTotalCharacters()
	-- Set Monies - No mouse interaction
	AltVault:SetTotalMoney()
	-- Set Time Played
	AltVault:SetTotalPlayed()

	self.AltListScrollFrame.update = UpdateAltList
	HybridScrollFrame_CreateButtons(self.AltListScrollFrame, "AltListButtonTemplate")
	UpdateAltList()

	local currentCharacter = AltVaultDB.characters[CharacterJournal.activeAlt].character
	local tabContainer = AltInfoTabContainerFrame
	if currentCharacter.bankWarned == false then
		tabContainer.BankTabHelpBox:Show()
	else
		tabContainer.BankTabHelpBox:Hide()
	end

	local tokenPrice = AltVaultDB.data.tokenPrice
	local tokenUpdated = AltVaultDB.data.tokenPriceUpdated
	if tokenPrice ~= nil and tokenUpdated ~= nil then
		local tokenAge = GetTokenAge(tokenUpdated)
		if tokenAge < 5 then
			AltVaultTokenIndicator.Icon:SetDesaturated(false)
		else
			AltVaultTokenIndicator.Icon:SetDesaturated(true)
		end
	else
		TokenPriceHelpBox:Show()
	end
end

function GetTokenAge(updatedData)
	local currentTime = C_DateAndTime.GetCurrentCalendarTime()
	local updatedDate = time{day=updatedData.monthDay, year=updatedData.year, month=updatedData.month}
	local currentDate = time{day=currentTime.monthDay, year=currentTime.year, month=currentTime.month}
	local daysPassed = difftime(currentDate, updatedDate) / (24 * 60 * 60) -- seconds in a day
	local wholeDays = math.floor(daysPassed)
	return wholeDays
end

function TokenIcon_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	local tokenPrice = AltVaultDB.data.tokenPrice
	local tokenUpdated = AltVaultDB.data.tokenPriceUpdated
	if tokenPrice ~= nil and tokenUpdated ~= nil then
		local tokenAge = GetTokenAge(tokenUpdated)
		local updatedDay = "today"
		if tokenAge == 1 then
			updatedDay = tokenAge.." day ago"
		elseif tokenAge > 1 then
			updatedDay = tokenAge.." days ago"
		end
		GameTooltip:SetText("WoW Token price updated "..updatedDay)
	else
		GameTooltip:SetText("Visit the Auction House\nto get a WoW Token price")
	end
end

function SetBankWarned(self)
	AltVaultDB.characters[CharacterJournal.activeAlt].character.bankWarned = true
	self:GetParent():Hide()
end

function AltVault:SetTotalCharacters()
	CharacterJournal.CharacterCount.Count:SetText(#core.AltVault.filteredCharacters)
end

function AltVault:SetTotalMoney()
	local totalMoney = 0
	for charID = 1, #core.AltVault.filteredCharacters do
		local character = AltVaultDB.characters[core.AltVault.filteredCharacters[charID]]
		totalMoney = totalMoney + tonumber(character.character.money)
	end
	AltVault:setMoneyValues(AltVaultMoneyTotal, totalMoney)
end

function AltVault:SetTotalPlayed()
	local totalTime = 0
	for charID = 1, #core.AltVault.filteredCharacters do
		local character = AltVaultDB.characters[core.AltVault.filteredCharacters[charID]]
		totalTime = totalTime + tonumber(character.character.played) 
	end
	CharacterJournal.TotalPlayed.Time:SetText(AltVault:Played_TimeBreakDown(totalTime, true))
end

function AltVault_OnLoad(self)
	AltVault:SetDefaultFilter()
	HybridScrollFrame_SetDoNotHideScrollBar(self.AltListScrollFrame, true)
	CharacterJournal.activeAlt = core.AltVault.filteredCharacters[1]
end

function AltVault:SetDefaultFilter()
	CharacterJournal.activeFilter = 1
	AltVault:GetFilteredCharacters()
	CharacterJournal.ListFilterButton:SetText(LIST_FILTERS[1])
end

--------------------------------------
-- Alt List ScrollList Functions
--------------------------------------

function UpdateAltList()
	local scrollFrame = CharacterJournal.AltListScrollFrame
    local buttons = HybridScrollFrame_GetButtons(scrollFrame)
    local offset = HybridScrollFrame_GetOffset(scrollFrame)
    for buttonIndex = 1, #buttons do
        local button = buttons[buttonIndex]
        local itemIndex = buttonIndex + offset

        if itemIndex <= #core.AltVault.filteredCharacters then
			local altInfo = AltVaultDB.characters[core.AltVault.filteredCharacters[itemIndex]]
            local altClass = string.gsub(altInfo.character.class, "%s+", "")
			local iconPath = "Interface\\ICONS\\ClassIcon_"..altClass
			SetPortraitToTexture(button.classIcon, iconPath)
			local _, _, _, colorCode = GetClassColor(strupper(altClass))
			button.altName:SetText(WrapTextInColorCode(altInfo.character.name, colorCode))
			local factionPath = "Interface\\COMMON\\icon-"..string.lower(altInfo.character.faction)
			button.ListFactionIcon:SetTexture(factionPath)

			AltVault:setMoneyValues(button.AltMoneyFrame, altInfo.character.money)

			if altInfo.character.hasMail then button.altHasMailIcon:Show() else button.altHasMailIcon:Hide() end
			if altInfo.character.restState == "Rested" and altInfo.character.restedXP ~= 0 then
				button.altRestedIcon:Show() 
			else 
				button.altRestedIcon:Hide()
			end

			if AltVaultDB.data.tokenPrice ~= nil and altInfo.character.money >= AltVaultDB.data.tokenPrice then
				button.altTokenIcon:Show()
			else
				button.altTokenIcon:Hide()
			end

			if core.AltVault.filteredCharacters[itemIndex] == CharacterJournal.activeAlt then
				button.selectedAlt:Show()
				button.classFrame:SetVertexColor(1.0, 0.7, 0.0)
			else
				button.selectedAlt:Hide()
				button.classFrame:SetVertexColor(1.0, 1.0, 1.0)
			end

			button.altServer:SetText(altInfo.character.realm)
			button.altLevel:SetText(altInfo.character.level)
			button:SetID(core.AltVault.filteredCharacters[itemIndex])
            button:Show()
        else
			button:Hide()
			AltVault:setMoneyValues(button.AltMoneyFrame, 0)
        end
	end

    local buttonHeight = buttons[1]:GetHeight()
    local totalHeight = #core.AltVault.filteredCharacters * buttonHeight
    local shownHeight = #buttons * buttonHeight
	HybridScrollFrame_Update(scrollFrame, totalHeight, shownHeight)
end

function AltListItem_OnClick(self)
	if CharacterJournal.activeAlt ~= self:GetID() then
		PlaySound(SOUNDKIT.IG_CHAT_SCROLL_UP)
	end 
	UpdateAltView(self:GetID())
end

function UpdateAltView(currentID)
	AltVaultItemsFrame:Hide()
	AltVaultBagsFrame:Hide()
	AltVaultBankFrame:Hide()
	AltVaultProfessionsFrame:Hide()
	CharacterJournal.activeAlt = currentID
	UpdateAltList()
	core.AltVaultCharacter:AltVaultUpdateAltInfo(CharacterJournal.activeAlt)
	core.AltVaultCharacter:AltVaultUpdateAltStats(CharacterJournal.activeAlt)
	AltVaultItemsFrame:Show()
	AltVaultBagsFrame:Show()
	AltVaultBankFrame:Show()
	AltVaultProfessionsFrame:Show()
end

function AltVaultTab_OnClick(self)
	local tabID = self:GetID()
	local container = AltInfoTabContainerFrame
	PlaySound(SOUNDKIT.IG_CHARACTER_INFO_TAB);
	PanelTemplates_SetTab(AltInfoTabContainerFrame, tabID)
	for pageNum = 1, NUM_PAGES do
		local page = container['page'..pageNum]
		if pageNum == tabID then
			page:Show()
		else
			page:Hide()
		end
	end
end

--------------------------------------
-- Filtering Functions
--------------------------------------

function AltVault:GetFilteredCharacters()
	core.AltVault.filteredCharacters = {}
	local currentID = AltVault:CurrentCharId()
	local currentCharacter = AltVaultDB.characters[currentID]
	local currentFaction = currentCharacter.character.faction
	local currentRealm = currentCharacter.character.realm
	local filter = CharacterJournal.activeFilter
	for id = 1, #AltVaultDB.characters do
		local charData = AltVaultDB.characters[id]
		local isCurrentFaction = charData.character.faction == currentCharacter.character.faction
		local onCurrentRealm = charData.character.realm == currentCharacter.character.realm
		if id ~= currentID then
			if filter == 1 then -- All Realms / All Factions
				table.insert(core.AltVault.filteredCharacters, id)
			elseif filter == 2 and isCurrentFaction then -- All Realms / Current Faction
				table.insert(core.AltVault.filteredCharacters, id)
			elseif filter == 3 and isCurrentFaction ~= true then -- All Realms / Opposite Faction
				table.insert(core.AltVault.filteredCharacters, id)
			elseif filter == 4 and onCurrentRealm then -- Current Realm / All Factions
				table.insert(core.AltVault.filteredCharacters, id)
			elseif filter == 5 and onCurrentRealm and isCurrentFaction then -- Current Realm / Current Faction
				table.insert(core.AltVault.filteredCharacters, id)
			elseif filter == 6 and onCurrentRealm and isCurrentFaction ~= true then -- Current Realm / Opposite Faction
				table.insert(core.AltVault.filteredCharacters, id)
			end
		end
	end
	-- Always have current character at the top of the list unless opposite faction filtered
	if filter ~= 3 and filter ~= 6 then
		table.insert(core.AltVault.filteredCharacters, 1, currentID)
	end
end

function AltVaultListFilterDropDown_OnLoad(self)
	UIDropDownMenu_Initialize(self, AltVaultListFilterDropDown_Initialize, "MENU");
end

function AltVaultListFilterDropDown_Initialize(self, level)
	local info = UIDropDownMenu_CreateInfo();
	for i = 1, #LIST_FILTERS do
		info.text = LIST_FILTERS[i];
		info.checked = i == CharacterJournal.activeFilter;
		info.func = function() AltVaultFilterList(i); end;
		UIDropDownMenu_AddButton(info);
	end
end

function AltVaultFilterList(filterID)
	local previousFilter = CharacterJournal.activeFilter
	CharacterJournal.activeFilter = filterID
	AltVault:GetFilteredCharacters()
	if #core.AltVault.filteredCharacters > 0 then
		UpdateAltView(core.AltVault.filteredCharacters[1])
		CharacterJournal.ListFilterButton:SetText(LIST_FILTERS[filterID])
		AltVault:SetTotalCharacters()
		AltVault:SetTotalMoney()
		AltVault:SetTotalPlayed()
	else
		CharacterJournal.activeFilter = previousFilter
		AltVault:GetFilteredCharacters()
		StaticPopup_Show("NO_FILTER_RESULTS")
	end
end

--------------------------------------
-- Utility Functions
--------------------------------------

function AltVaultTooltip_Reset(self)
	GameTooltip:Hide()
	if (BattlePetTooltip) then
		BattlePetTooltip:Hide();
	end
	ResetCursor()
end

function AltVault:UpdateViews()
	CharacterJournal:Hide()
	CharacterJournal.activeAlt = core.AltVault.filteredCharacters[1]
	CharacterJournal:Show()
end

function AltVault:CurrentCharId()
	local currentId = 1
	currentGUID = UnitGUID("player")
	for key, char in ipairs(AltVaultDB.characters) do
		if char.GUID == currentGUID then
			currentId = key
		end
	end
	return currentId
end

function AltVault:setMoneyValues(moneyContainer, total)
	local _, cButton, sButton, gButton = moneyContainer:GetChildren()
	local gold = floor(total / (COPPER_PER_SILVER * SILVER_PER_GOLD))
	local goldDisplay = BreakUpLargeNumbers(gold)
	local silver = floor((total - (gold * COPPER_PER_SILVER * SILVER_PER_GOLD)) / COPPER_PER_SILVER)
	local copper = mod(total, COPPER_PER_SILVER)

	gButton:SetText(goldDisplay)
	gButton:EnableMouse(false)
	sButton:SetText(silver)
	sButton:EnableMouse(false)
	cButton:SetText(copper)
	cButton:EnableMouse(false)
end

function AltVault:Played_TimeBreakDown(time, long)
	local days = tostring(floor(time / (60 * 60 * 24)))
	local hours = tostring(floor((time - (days * (60 * 60 * 24))) / (60 * 60)))
	local minutes = tostring(floor((time - (days * (60 * 60 * 24)) - (hours * (60 * 60))) / 60))
	local seconds = tostring(mod(time, 60))
	local dayLabel = days == "1" and " day, " or " days, "
	local hourLabel = hours == "1" and " hour, " or " hours, "
	local minuteLabel = minutes == "1" and " minute, " or " minutes, "
	local secondLabel = seconds == "1" and " second" or " seconds"
	if long then
		return days..dayLabel..hours..hourLabel..minutes..minuteLabel..seconds..secondLabel
	else
		return days..dayLabel..hours..":"..minutes..":"..seconds
	end
end