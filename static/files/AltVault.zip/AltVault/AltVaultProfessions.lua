--------------------------------------
-- Namespaces
--------------------------------------
local _, core = ...
core.AltVaultProfessions = {}

local AltVault = core.AltVault
local AltVaultProfessions = core.AltVaultProfessions

function AltVaultProfessionsFrame_OnShow(self)
    UpdateProfessions()
    -- Setup icons for secondary professions
    AltProfessionsSecondaryCook.Icon:SetTexture("Interface\\ICONS\\Inv_Misc_Food_15")
    AltProfessionsSecondaryCook.Icon:SetVertexColor(0.6, 0.4, 0.2, 0.7)
    AltProfessionsSecondaryFish.Icon:SetTexture("Interface\\ICONS\\Trade_Fishing")
    AltProfessionsSecondaryFish.Icon:SetVertexColor(0.6, 0.4, 0.2, 0.7)
    AltProfessionsSecondaryArch.Icon:SetTexture("Interface\\ICONS\\TRADE_ARCHAEOLOGY")
    AltProfessionsSecondaryArch.Icon:SetVertexColor(0.6, 0.4, 0.2, 0.7)
end

function UpdateProfessions()
    local professionData = AltVaultDB.characters[CharacterJournal.activeAlt].professions
    if professionData == nil then return end
    -- Profession 1
    UpdateProfessionSlot(AltProfessionsPrimaryProf1, professionData.prof1, true)
    -- Profession 2
    UpdateProfessionSlot(AltProfessionsPrimaryProf2, professionData.prof2, true)
    -- Cooking
    UpdateProfessionSlot(AltProfessionsSecondaryCook, professionData.cook, false)
    -- Fishing
    UpdateProfessionSlot(AltProfessionsSecondaryFish, professionData.fish, false)
    -- Archaeology
    UpdateProfessionSlot(AltProfessionsSecondaryArch, professionData.arch, false)
end

function UpdateProfessionSlot(ProfSlot, profData, isPrimary)
    if profData ~= nil then
        -- Primary Specific
        if isPrimary then
            -- Specialization
            if profData.specializationName ~= nil then
                ProfSlot.ProfSpecialization:SetText(profData.specializationName)
                ProfSlot.ProfSpecialization:Show()
            else
                ProfSlot.ProfSpecialization:Hide()
            end
            -- Icon
            ProfSlot.Icon:SetMask(nil)
            ProfSlot.Icon:SetTexture(profData.icon)
            ProfSlot.Icon:SetMask("Interface\\CharacterFrame\\TempPortraitAlphaMask")
        end
        -- Unlearned
        ProfSlot.Unlearned:Hide()
        -- Name
        ProfSlot.ProfTitle:SetText(profData.name)
        ProfSlot.ProfTitle:Show()
        -- Skill Level
        ProfSlot.ProfRank:SetText(profData.skillName)
        ProfSlot.ProfRank:Show()
        -- Skill Bar
        ProfSlot.statusBar:SetMinMaxValues(1,profData.maxSkill);
        ProfSlot.statusBar:SetValue(profData.skill);

        if ( profData.skillModifier > 0 ) then
			ProfSlot.statusBar.rankText:SetFormattedText(TRADESKILL_RANK_WITH_MODIFIER, profData.skill, profData.skillModifier, profData.maxSkill);
		else
			ProfSlot.statusBar.rankText:SetFormattedText(TRADESKILL_RANK, profData.skill, profData.maxSkill);
        end
        
        if profData.skill == profData.maxSkill then
			ProfSlot.statusBar.capRight:Show();
		else
			ProfSlot.statusBar.capRight:Hide();
        end
        ProfSlot.statusBar:Show()
    else
        -- Primary Specific
        if isPrimary then
            -- Specialization
            ProfSlot.ProfSpecialization:Hide()
            -- Title
            ProfSlot.ProfTitle:Hide()
            -- Icon
            ProfSlot.Icon:SetMask(nil)
            ProfSlot.Icon:SetTexture("Interface\\ICONS\\INV_Scroll_03")
            ProfSlot.Icon:SetMask("Interface\\CharacterFrame\\TempPortraitAlphaMask")
        end
        -- Hide data for unlearned
        ProfSlot.ProfRank:Hide()
        ProfSlot.statusBar:Hide()
        -- Show Unlearned Text
        ProfSlot.Unlearned:Show()
    end
end