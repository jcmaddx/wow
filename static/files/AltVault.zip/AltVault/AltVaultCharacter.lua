--------------------------------------
-- Namespaces
--------------------------------------
local _, core = ...
core.AltVaultCharacter = {}

local AltVault = core.AltVault
local AltVaultCharacter = core.AltVaultCharacter

local MAX_LEVEL = 120

--------------------------------------
-- Delete Alt Data
--------------------------------------

StaticPopupDialogs["DELETE_ALT_DATA"] = {
    text = "Are you sure you want to delete this Character's Data?",
    button1 = "Yes",
    button2 = "No",
    OnAccept = function()
        AltVaultDeleteAlt()
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3
}

function AltDelete_OnClick(self)
	StaticPopup_Show("DELETE_ALT_DATA")
end

function AltVaultDeleteAlt()
	table.remove(AltVaultDB.characters, CharacterJournal.activeAlt)
	if #core.AltVault.filteredCharacters == 1 then
		AltVault:SetDefaultFilter()
	else
		AltVault:GetFilteredCharacters()
	end
	AltVault:UpdateViews()
end

function AltDeleteFrame_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	GameTooltip:SetText("Delete Character Data")
end

--------------------------------------
-- Character Info Section
--------------------------------------

function AltRaceIconFrame_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	local curAlt = AltVaultDB.characters[CharacterJournal.activeAlt]
	local race = curAlt.character.race
	local gender = curAlt.character.sex:gsub("^%l", string.upper)
	GameTooltip:SetText(race.." "..gender)
	CursorUpdate(self)
end

function AltSpecIconFrame_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	local curAlt = AltVaultDB.characters[CharacterJournal.activeAlt]
	local spec = curAlt.character.specName
	local class = curAlt.character.class
	local role = curAlt.character.role
	GameTooltip:SetText(spec.." "..class)
	CursorUpdate(self)
end

function AltXPBarFrame_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	local curAlt = AltVaultDB.characters[CharacterJournal.activeAlt]
	local percent = curAlt.character.xp / curAlt.character.xpMax
	if curAlt.character.level == MAX_LEVEL then
		percent = 1
	end
	percent = tostring(ceil(percent * 100)).."%"
	GameTooltip:SetText(percent)
end

function AltVaultInfo_OnShow(self)
	AltVaultCharacter:AltVaultUpdateAltInfo(CharacterJournal.activeAlt)
end

function AltVaultCharacter:AltVaultUpdateAltInfo(altId)
	local emblem = AltVaultInfo.AltClassEmblem
    local curAlt = AltVaultDB.characters[altId]
	local altClass = string.lower(string.gsub(curAlt.character.class, "%s+", ""))
	local emblemTexture = "Interface\\Pictures\\artifactbook-"..altClass.."-cover"

	if curAlt.GUID == UnitGUID("player") then
		AltDeleteFrame:Hide()
	else
		AltDeleteFrame:Show()
	end

	emblem:SetTexture(emblemTexture)
	emblem:SetVertexColor(1.0, 0.7, 0.0, 0.4)
	if altClass == 'demonhunter' then
		emblem:SetSize(180, 180)
	else
		emblem:SetSize(150, 150)
	end

	if curAlt.character.title ~= nil then
		local titleBefore = false
		local titleTrim = curAlt.character.title:gsub("^%s*(.-)%s*$", "%1")
		if #titleTrim < #curAlt.character.title then
			AltVaultInfo.AltInfoName:SetPoint("TOP", AltVaultInfo, "TOP", 0, -35)
			AltVaultInfo.AltInfoTitle:SetPoint("TOP", AltVaultInfo, "TOP", 0, -20)
			AltVaultInfo.AltInfoTitle:SetText(titleTrim)
		else
			AltVaultInfo.AltInfoName:SetPoint("TOP", AltVaultInfo, "TOP", 0, -20)
			AltVaultInfo.AltInfoTitle:SetPoint("TOP", AltVaultInfo, "TOP", 0, -42)
			AltVaultInfo.AltInfoTitle:SetText(curAlt.character.title)
		end
		AltVaultInfo.AltInfoName:SetText(curAlt.character.name)
	else
		AltVaultInfo.AltInfoName:SetPoint("TOP", AltVaultInfo, "TOP", 0, -22)
		AltVaultInfo.AltInfoName:SetText(curAlt.character.name)
		AltVaultInfo.AltInfoTitle:SetText("")
	end
	
	local noSpaceRace = string.gsub(curAlt.character.race, "%s+", "")
	local noSpecialRace = string.gsub(noSpaceRace, "'", "")
	local raceString = string.lower(noSpecialRace)
	if raceString == 'highmountaintauren' then
		raceString = "highmountain"
	elseif raceString == 'lightforgeddraenei' then
		raceString = "lightforged"
	end

	local iconAtlas = "raceicon-"..raceString.."-"..curAlt.character.sex
	AltRaceIconFrame.altRaceIcon:SetMask(nil)
	AltRaceIconFrame.altRaceIcon:SetAtlas(iconAtlas)
	AltRaceIconFrame.altRaceIcon:SetMask("Interface\\CharacterFrame\\TempPortraitAlphaMask")
	SetPortraitToTexture(AltSpecIconFrame.altSpecIcon, curAlt.character.specBackground)

	AltRoleIconFrame.roleIcon:SetTexCoord(GetTexCoordsForRole(curAlt.character.role))

	local guildTabard = AltVaultStatsFrame.AltTabard
	local guildName = AltVaultStatsFrame.AltGuildName
	local guildRank = AltVaultStatsFrame.AltGuildRank
	if curAlt.guild ~= nil then
		guildTabard.emblemFull:Hide()
		local tabardData = curAlt.guild.tabard
		guildTabard.background:SetVertexColor(tabardData.bgR, tabardData.bgG, tabardData.bgB)
		guildTabard.border:SetVertexColor(tabardData.borderR, tabardData.borderG, tabardData.borderB)
		guildTabard.emblemLeft:SetTexture(tabardData.emblemTexture)
		guildTabard.emblemLeft:SetVertexColor(tabardData.emblemR, tabardData.emblemG, tabardData.emblemB)
		guildTabard.emblemLeft:Show()
		guildTabard.emblemRight:SetTexture(tabardData.emblemTexture)
		guildTabard.emblemRight:SetVertexColor(tabardData.emblemR, tabardData.emblemG, tabardData.emblemB)
		guildTabard.emblemRight:Show()
		guildRank:SetText(curAlt.guild.rank.." in")
		guildRank:Show()
		guildName:SetPoint("BOTTOMLEFT", 20, 20)
		guildName:SetText(curAlt.guild.name)
	else
		guildTabard.emblemRight:Hide()
		guildTabard.emblemLeft:Hide()
		guildTabard.border:SetVertexColor(0.6, 0.4, 0.2)
		guildTabard.background:SetVertexColor(0.9, 0.7, 0.3)
		guildTabard.emblemFull:Show()
		guildRank:Hide()
		guildName:SetPoint("BOTTOMLEFT", 25, 35)
		guildName:SetText("No Guild")
	end
	guildTabard:Show()
	AltVaultStatsFrame.AltPvPTitle:SetText("Honor Level "..curAlt.pvp.honorLevel)
	AltPvPTierIconFrame.icon:SetTexture(curAlt.pvp.tierIcon)
	AltVaultStatsFrame.AltPVPHKCount:SetText(BreakUpLargeNumbers(curAlt.pvp.kills))

	local playedString = AltVault:Played_TimeBreakDown(curAlt.character.played, false)
	AltVaultStatsFrame.AltPlayedTime:SetText(playedString)
	
	AltItemLevelFrame.AltItemLevel:SetText(curAlt.character.ilvl)
	AltItemLevelFrame.AltItemLevel:SetTextColor(
		curAlt.character.ilvlColor.red, 
		curAlt.character.ilvlColor.green, 
		curAlt.character.ilvlColor.blue
	)

	local xpMax = tostring(BreakUpLargeNumbers(curAlt.character.xpMax))
	local xp = tostring(BreakUpLargeNumbers(curAlt.character.xp))
	local xpRatio = xpMax.." / "..xpMax
	local percent = 1
	local width = 230
	if curAlt.character.level ~= MAX_LEVEL then
		percent = curAlt.character.xp / curAlt.character.xpMax
		xpRatio = xp.." / "..xpMax
		width = width * percent
	end

	AltXPBarFrame.altXPLevel:SetText(curAlt.character.level)
	AltXPBarFrame.altXPProgressBar:SetWidth(width)
	AltXPBarFrame.altXPPercent:SetText('XP: '..xpRatio)
end

--------------------------------------
-- Alt Equipped Items Rendering
--------------------------------------

function AltItemSlotButton_OnShow(self)
	local name = self:GetName()
	local slotName = string.upper(strsub(name, 4))
	local id, textureName, checkRelic = GetInventorySlotInfo(slotName)
	local equippedItem = AltVaultDB.characters[CharacterJournal.activeAlt]["gear"][slotName]
	local texture = _G[name.."IconTexture"]
	self:SetID(id)
	if equippedItem ~= nil then
		local item = Item:CreateFromItemLink(equippedItem)
		item:ContinueOnItemLoad(function()
			local itemName, itemHyperLink, itemRarity, _, _, _, _, _, _, itemTexture = GetItemInfo(equippedItem)
			texture:SetTexture(itemTexture)
			SetItemButtonQuality(self, itemRarity, id)
		end)
	else
		texture:SetTexture(textureName)
		SetItemButtonQuality(self, 1, id)
		self.backgroundTextureName = textureName
	end
end

function AltItemSlotButton_OnModifiedClick(self, button)
	local name = self:GetName()
	local slotName = string.upper(strsub(name, 4))
	local equippedItem = AltVaultDB.characters[CharacterJournal.activeAlt]["gear"][slotName]
	local _, itemHyperLink = GetItemInfo(equippedItem)
	HandleModifiedItemClick(itemHyperLink)
end

--------------------------------------
-- Alt Equipped Items Tooltips
--------------------------------------

function AltItemSlotButton_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	local name = self:GetName()
	local slotName = string.upper(strsub(name, 4))
	local equippedItem = AltVaultDB.characters[CharacterJournal.activeAlt]["gear"][slotName]
	if ( equippedItem ) then
		GameTooltip:SetHyperlink(equippedItem)
	else
		local text = _G[strupper(slotName)]
		GameTooltip:SetText(text)
	end
	CursorUpdate(self)
end


--------------------------------------
-- Character Guild / PVP Section
--------------------------------------

function AltVaultStats_OnShow(self)
	AltVaultCharacter:AltVaultUpdateAltStats(CharacterJournal.activeAlt)
end

function AltVaultCharacter:AltVaultUpdateAltStats(altId)
	local curAlt = AltVaultDB.characters[altId]
	local faction = curAlt.character.faction
	local logoTexture = "Interface\\Timer\\"..faction.."-Logo"
	AltVaultStatsFrame.AltStatsFactionLogo:SetTexture(logoTexture)
	AltVaultStatsFrame.AltStatsFactionLogo:SetVertexColor(0.5, 0.5, 0.5, 0.8)
end

function AltPvPTierIconFrame_OnEnter(self)
	GameTooltip:SetOwner(self, "ANCHOR_TOP")
	local curAlt = AltVaultDB.characters[CharacterJournal.activeAlt]
	local honorText = "Honor: "..curAlt.pvp.honor..'/'..curAlt.pvp.maxHonor
	if curAlt.character.level == MAX_LEVEL then
		honorText = honorText.."\nConquest: "..curAlt.pvp.currentConquest..'/'..curAlt.pvp.maxConquest
	end
	GameTooltip:SetText(honorText)
end